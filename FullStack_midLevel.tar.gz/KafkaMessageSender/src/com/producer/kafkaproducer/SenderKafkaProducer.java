package com.producer.kafkaproducer;

public class SenderKafkaProducer {

}
