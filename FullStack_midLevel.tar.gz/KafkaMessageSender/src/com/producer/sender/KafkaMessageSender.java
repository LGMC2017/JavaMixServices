package com.producer.sender;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import messages.client.common.IMessageSender;

public class KafkaMessageSender implements IMessageSender {
	
	private static final String KAFKA_SERVER_URL = "127.0.0.1";
	private static final String KAFKA_SERVER_PORT = "9092";
	private static final String KAFKA_TOPIC = "TestTopic";
	private final Properties properties;
	
	public KafkaMessageSender() {
		this.properties = new Properties();
	}
	
	public KafkaMessageSender(Properties properties) {
		this.properties = properties;
	}

	@Override
	public void sendMessage(String strMessage) {
				
		properties.put("bootstrap.servers", KAFKA_SERVER_URL + ":" + KAFKA_SERVER_PORT);
		properties.put("client.id", "DemoProducer");
		properties.put("key.serializer", "org.apache.kafka.common.serialization.IntegerSerializer");
		properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		KafkaProducer<String,String> producer = new KafkaProducer<String,String>(properties);
		
		try {
			
		    producer.send(new ProducerRecord<String,String>(KAFKA_TOPIC, strMessage)).get();
		    producer.close();
		    
		} 
		catch (InterruptedException | ExecutionException e) {
			
		    e.printStackTrace();
		    System.out.println(e.getMessage());
		}
	}

	@Override
	public void sendFile(String filepath) throws IOException {
		
		BufferedReader br = new BufferedReader(new FileReader(filepath));
		try {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    String message = sb.toString();
		    sendMessage(message);
		} finally {
		    br.close();
		}
	}

}
