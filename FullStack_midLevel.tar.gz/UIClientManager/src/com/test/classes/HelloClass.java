package com.test.classes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import messages.client.common.IMessageSender;

public class HelloClass {

	private String message;
	private String topicName;

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		IMessageSender sender = (IMessageSender) context.getBean("kafkaSender");
		HelloClass obj = (HelloClass) context.getBean("helloWorld");
		String smessage = obj.getHello();
		System.out.println(smessage);
	}

	public String getHello() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public void getMessage() {
		System.out.println("Your Message : " + message);
	}

}
