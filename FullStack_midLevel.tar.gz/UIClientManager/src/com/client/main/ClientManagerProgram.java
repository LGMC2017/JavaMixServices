package com.client.main;

import java.util.Properties;
import javax.swing.JDialog;
import javax.swing.JFrame;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.producer.ui.MainWindow;
import com.test.classes.HelloClass;

import messages.client.common.IMessageSender;

public class ClientManagerProgram {
	
	public static void main(String[] args) {
		launchProgram();
	}

	private static void launchProgram() {
		
		final boolean windecorated = true;
		JFrame.setDefaultLookAndFeelDecorated(windecorated);
		JDialog.setDefaultLookAndFeelDecorated(windecorated);
		
		//spring beans
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		IMessageSender ksender = (IMessageSender) context.getBean("kafkaSender");
		
		//testing spring 
		/*********************************/
			HelloClass obj = (HelloClass) context.getBean("helloWorld");
			String smessage = obj.getHello();
			System.out.println(smessage);
		/*********************************/
		
		Properties props = new Properties();
		MainWindow mw = new MainWindow(ksender);
		mw.setVisible(true);
	}


}
