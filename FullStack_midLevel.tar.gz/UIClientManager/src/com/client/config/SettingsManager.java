package com.client.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class SettingsManager {
	
	private static Properties properties;
	
	private SettingsManager(String filepath) throws IOException {
		File fileobj = new File(filepath);
		properties = new Properties();
		
		if(fileobj.exists()) {
			FileInputStream fstream = new FileInputStream(fileobj);
			properties.load(fstream);
			fstream.close();
		}
		
		if(properties.isEmpty()) {
			return;
		}
	}
	
	public String getVal(String key) {
		return properties.getProperty(key);
	}
	
	//===============================================================//
	public static void main(String[] args) {
		String filepath = "settings.properties";
		try {
			SettingsManager setman = new SettingsManager(filepath);
			String s1 = setman.getVal("VALUE1");
			String s2 = setman.getVal("VALUE2");
			String s3 = setman.getVal("VALUE3");
			String stotal = s1.concat(s2).concat(s3);
			System.out.println(stotal);
		}
		catch(IOException ex) {
			System.out.println(ex.getMessage());
		}
		
	}


}
