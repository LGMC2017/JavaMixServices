package com.producer.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
//import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import messages.client.common.IMessageSender;


public class MainWindow extends JFrame {

	//static vars
	private static final long serialVersionUID = 1L;
	private static final int WWIDHT = 650;
	private static final int WHEIHGT = 400;
	private static final Dimension WINDIM = new Dimension(WWIDHT / 2, WHEIHGT / 2);	
	
	//ui swing components
	private JPanel[] panels;
	private static final JButton btnSend = new JButton("Send Text");
	private static final JButton btnFile = new JButton("JSON file");
	//private static final JButton btnTemp = new JButton("Temp");
	private static final JMenuBar menubar = new JMenuBar();
	private static final JMenu menuFile = new JMenu("File");
	private static final JMenuItem mnuItem1 = new JMenuItem("Close");
	
	private static final JTextField txtSend = new JTextField(15);
	private static final JFileChooser fchooser = new JFileChooser();
	private static final JLabel lbl1 = new JLabel("Message:");	
	private IMessageSender messagesender = null;
	
	public MainWindow() {
		super();
		setSize(WINDIM);
		setTitle("Kafka Sender");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		initComponents();
	}
	
	public MainWindow(IMessageSender _msgsender) {
		this();
		this.messagesender  = _msgsender;
	}
	
	public void setMessageSender(IMessageSender _msgsender) {
		this.messagesender = _msgsender;
	}
	
	private void initComponents() {
		
		panels = new JPanel[2];
		panels[0] = new JPanel();
		panels[0].setBorder(new EmptyBorder(10, 10, 10, 10));
		panels[1] = new JPanel();
		
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(panels[0], BorderLayout.NORTH);
		this.getContentPane().add(panels[1], BorderLayout.CENTER);
		
		menubar.add(menuFile);
		menuFile.addSeparator();
		menuFile.add(mnuItem1);		
		this.setJMenuBar(menubar);		
		
		panels[0].add(lbl1);
		panels[0].add(txtSend);
		panels[1].setLayout(new FlowLayout());
		panels[1].add(btnSend);
		panels[1].add(btnFile);
		//panels[1].add(btnTemp);

		handleEvents();
	}
	
	private void handleEvents() {
		
		btnSend.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				String message = txtSend.getText();
				
				if(!message.isEmpty()) {
					System.out.println("Sending: " + message);				
					if(messagesender != null) {
						messagesender.sendMessage(message);
					}
				}
			}
		});
		
		btnFile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int returnVal = fchooser.showOpenDialog(MainWindow.this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					File selfile = fchooser.getSelectedFile();
					System.out.println(selfile.getPath());
					if(selfile.exists()) {
						try {
							messagesender.sendFile(selfile.getPath());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
		});
		
		mnuItem1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
//		btnTemp.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				JOptionPane.showConfirmDialog(MainWindow.this, "Message");
//			}
//		});
	}
}
