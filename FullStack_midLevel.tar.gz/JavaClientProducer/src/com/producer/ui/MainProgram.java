package com.producer.ui;

import javax.swing.JDialog;
import javax.swing.JFrame;

public class MainProgram {

	public static void main(String[] args) {
		launchProgram();
	}

	private static void launchProgram() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		MainWindow mw = new MainWindow();
		mw.setVisible(true);
	}

}
