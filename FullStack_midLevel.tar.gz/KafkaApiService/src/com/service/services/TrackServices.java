package com.service.services;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.service.entities.TrackLog;

@Path("/library")
@Consumes({ "application/json" })
@Produces({ "application/json" })
public class TrackServices {

	@GET
	@Path("/test")
	public String test() {
		return "Testing";
	}
	
	@GET
	@Path("/test/{id}")
	public String test(@PathParam("id") int id) {
		return "Testing for " + id;
	}
	
	/*
	 * i/e: http://localhost:8080/KafkaApiService/library/test/1?detail=somedetails
	 * Header: Content-Type : application/json
	 * */
	@PUT
	@Path("/test/{id}")
	public TrackLog addTrack(@PathParam("id") String id, @QueryParam("detail") String detail) {
		TrackLog trlog = new TrackLog();
		trlog.setTrackId(Integer.parseInt(id));
		trlog.setDetail(detail);
		return trlog;
	}
	
	/*
	 * i/e: http://localhost:8080/KafkaApiService/library/test2/1
	 * body: 	Some tracking details
	 * Header: Content-Type : application/json
	 * */
	@PUT
	@Path("/test2/{id}")
	public TrackLog addTrack2(@PathParam("id") String id, String detail) {
		TrackLog trlog = new TrackLog();
		trlog.setTrackId(Integer.parseInt(id));
		trlog.setDetail(detail);
		return trlog;
	}
	
}
